<?php
	// Sistema de Controle de Estrangeiro - Autor: Gabriel Henrique Martinez Saraiva
	// Titulo da página
	echo ("Sistema de Controle de Estrangeiro");
?>