<?php

/* Autor: Gabriel Henrique Martinez Saraiva
 * Arquivo para criar o usuário admin.
 * Posteriormente esse arquivo será expandido para inicializar todo o banco de
 * dados.
 */

echo md5("sce");

?>
